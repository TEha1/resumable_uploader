import sys
from argparse import ArgumentParser

if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument("--column", help="column argument", required=True)
    parser.add_argument("--max_count", help="max_count argument", required=True)
    parser.add_argument("--max_value", help="max_value argument", required=True)
    args = parser.parse_args()
    column = int(args.column)
    max_count = int(args.max_count)
    max_value = float(args.max_value)

    condition_counter = 0
    for index, line in enumerate(sys.stdin):
        if index < 2:
            # to skip first two line because they are empty
            continue
        print(line, end="")
        current_value = float(line.split(",")[int(column)].strip().replace('"', ""))
        current_count = index - 1
        if current_value > max_value:
            condition_counter += 1
            if condition_counter == max_count:
                condition_counter = 0
                print(
                    f"column {column} has gone over {max_value} more than {max_count} times"
                )
