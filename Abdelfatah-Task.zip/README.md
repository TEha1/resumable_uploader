# Task
I want to monitor a value produced from a streaming app; say one of the columns from
a typeperf command. If it goes over a certain value for a certain amount of time I'd like a
message printed out.
Example of typeperf: typeperf "\System\Processes" "\Process(_Total)\% Processor Time"
"\Memory\Available MBytes"
Example running: python yourscript.py --column=3 --max_count=5 --max_value=200
That means that when column 3 has gone over 200 more than 5 times, print something out.